from gendiff.gendiff import generate_diff
from gendiff.parser import parse_args


__all__ = (
    'generate_diff',
    'parse_args'
)
