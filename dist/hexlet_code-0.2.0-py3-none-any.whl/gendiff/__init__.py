from gendiff.gendiff import generate_diff
from gendiff.parser import arg_parser


__all__ = (
    'generate_diff',
    'arg_parser'
)
